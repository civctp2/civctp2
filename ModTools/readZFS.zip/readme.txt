ReadZFSFile version 2.2.0.6
Date: 31-01-2002

Description:

.zfs unpacker for Civ:CTP and CTP2
This program can be used to: 
     -  unpack .zfs-files
     -  extract files from .zfs-files
     -  convert .rim-files found in .zfs-files to three widely used formats.


Whats new: (Changes from version 2.2.0.5)
- Added 'default file type' option so files with no or invalid extentions
        can be viewed.
- Fixed bug where play, pause, and stop buttons where not displayed.

Changes from version 2.2.0.4
The whole code has recieved a major overhaul, resulting in significant 
increases in speed and decrease in memory usage.
- Loading and caching now happends in the background. (seperate threads)
- Removed loading file animation.
- Added an Options-dialog.
- Added 'Persistent Dirs' option - determins wether or not to remember the
        last used directories to next session.
- Added 'Always Use Default Dirs' option - determins wether the Open and 
        Save dialogs remembers the dir used or reverts to default each time.
- Added 'Enable Caching' option - determins wether ReadZFSFile leaves the 
        files that has been displayed in memory or reads them from disk.
- Added 'Auto Cache' option - cache files on open.
- Added 'Load Data' - loads all files into memory.
- Added 'Unload Data' - unloads all files from memory.
- Images can now be saved as:
        .rim      - Native CTP format
        .tga      - TrueVission targa
        .bmp      - Windows Bitmap
        .jpg/jpeg - JPEG Image File
- All truncated file extentions are now treated as txt, rim, or wav.
- .zfs-files can now be passed to ReadZFSFile on the command line.
       Makes double-clicking possible (se Installation)

Changes from version 2.1.0.3
- Fixed remember last dir so it now works as intended.
- Added Zoom for images (from 20% - 1600%)
- Added loading file animation.

Changes from version 2.0.0.2
- Fixed Save All Files: now _all_ files are saved, not just the selected file.

- Added:
    Multi-Select: Allows more than one file to be saved in one operation. 
                  This will use the filenames from the .zfs-file with no 
                  overwrite protection, as in Save All Files.
    Find File   : Find a file of a given name within the .zfs-file.
    Find Text   : Find a given text-string within the text-files found
                  in the .zfs-file.
- The Export directory used for multiple files is now the same as the
  "Save-File" directory, and is stored.

Changes from version 2.0.0.1
- .waw files with truncated extentions (.wa and .w) are now treated 
  as .waw files.
- the play, pause, and stop buttons for .waw files now work as intended.
- ReadZFSFile will now remember the last directories used for save/open.

Changes from version 1.0

The .rim files contained in the .zfs files found in the graphics 
sections can be viewed and saved either as .rim files or as 16 bit 
TrueVision Targa (mode 2) images (the format used by Civ:CTP and CTP2).

ReadZFSFile can now play-back and save .wav files found in the Sound
sections. (This creates a .wav file in the windows temp directory. The 
file will be deleted at a normal closedown of the application. In case
of forced closedown look for a file named zfs#####.wav where each # 
represents a hex-digit 0-9 and a-f).


Installation:

Just unzip and put the file where you want to have it.
If there are problems with these files, let me know, and I might be able
to do something about it, but remember that the files are provided as is,
so use at your own risk.
To Make double-clicking possible, start the program, go to Options and
press the <Register .zfs> button.

Usage:
Start the program, select <Open> from the File menu and select the .zfs
file you want to unpack. The program wil then list the files 
contained within the .zfs-file. When you select a file from the list
the contents will show up in the right window.
Either copy text from here or select <Save> on the File menu to save
the file.

To save multiple files usein the keyboard or <Shift> and/or <Ctrl> and the
left mouse-button.

To save all files in an archive select <Save files> on the File menu.

To save .rim files as one of the supported formats just give the file the
appropriate extention or select the file type from the 'Save as type' 
drop down list, give the file the tga extention, or while saving multiple
files select the appropriate radio-item on the Select-Directory dialog.


Note!

Caching takes up a lot of memory so don't use it for large files unless
you have more RAM than the size of the .zfs-file being opened.
There is no over-write warning.

The legal stuff:

   -- The programmer is not in any way connected to Activision. --
     -- THIS PROGRAM IS NOT MADE OR SUPPORTED BY ACTIVISION. --

The files are provided as is, with no guarantee that they will not have 
any undesired side effects.

Any mod maker is welcome to use files extracted using ReadZFSFile in their 
mods as long as they include this file in the mod or puts the following 
text (or a similar statement) in their readme file:

  Some of the material in this mod was extracted using ReadZFSFile by
  Martin B. Vestergaard 
  mtd@mbv.dk
  http://mbv.dk/uk

Martin the Dane. aka. Martin B. Vestergaard
mtd@mbv.dk
http://mbv.dk/uk
