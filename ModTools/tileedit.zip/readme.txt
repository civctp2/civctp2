This is a .til file viewer/editor, for CTP/CTP2 tiles.
   
   Please feel free to distribute this program under the conditions
   stated below. The newest version can be found at:
   http://mbv.dk/tileedit

The legal stuff: (oh how I hate this but it's got to be there)

   Distribution:
   This program may NOT under any circumstances be distributed
   on any read-only media, or as part of any software package,
   including modifications to games without explicit written
   permission from the programmer.
   
   Usage:
   This program is the property of the programmer, 
   Martin B. Vestergaard. You may use it only to view and extract
   graphics from tile-files and generate new tile-files for the 
   Call to Power games. You may not make any charge for any material
   generated/extracted by this program.

   Warranty:
   This program is provided "as is" , without warranty of any
   kind, either expressed or implied. The use of the program
   is your own responsibility, and the programmer will NOT
   accept any claims what so ever.
   
   -- The programmer is not in any way connected to Activision. --
   -- THIS PROGRAM IS NOT MADE OR SUPPORTED BY ACTIVISION. --

So what can it do?
View, save, and change all the good stuff that's in the .til files.

I had given up the hope of doing anything useful until Martin G�hmann took a look at my early work and discovered the layout of the tiles within the .til-files. It turned out to be a setup I had dismissed from the start as being not practical and unsuitable for isometric tiles (say stupid). 
So what did I learn from that? ... Don't ever dismiss any idea because it seems absolutely stupid, because someone else might think it's ingenious ;) In fact it's not such a bad idea after all.

We have now identified most of the contents of the .til-files (well Martin did most of that), and all known aspects has been fully implemented.
TileEdit can now view and edit all TileBorders, Terrain Tiles, Rivers, and Tile Improvements (and a block of unknown meaning).

How you can help:

Drop me a note if you have any suggestions for functions for the finished program.

We need some help figuring out the meaning of the last blocks in the .til (for now called 'LastBlock').

If you wish to help, please contact me, for an update on current progress and specific tasks.

Martin B. Vestergaard (aka. Martin the Dane) mtd@mbv.dk

Usage:

When the program starts a blank .til-file is created in memory, this can be edited by adding, deleting, or editing the various elements.
It is also possible to open an existing .til-file, and edit that.
The result can be saved as two .til-files, one is not used by the game (as far as we know) but uses normal color format as in uncompressed TGA's. The other is the actual file being used in the game. This file uses an alternative color format. Both formats can be opened by TileEdit.

To Change the graphics use any graphics editor to create your image, then save it as uncompressed RGB tga's (16, 24, or 32 bit). the standard size for Tiles and borders are 94x72 pixel, for Rivers and TileImprovements it's variable, with the same origin as the Tile graphics (upper, left).
(The graphics-import can handle 16, 24, and 32 bit uncompressed RGB TGA-files.)
On the load TGA-screen use <Ctrl>+ Left or Right mouse burton to select the transparent and shadow color respectively.
Do not use the following colors in the tga-files you import into TileEdit:
16 bit colors: the colors (R,G,B) 0,0,0 - 0,0,3
24 and 32 bit colors: the colors (R,G,B) 0,0,0 - 0,0,24
As these are used for special purpouses in the .til-file.

It is possible to save the individual graphical elements as TGA-files, and the image in the preview pane can be saved as Windows Bitmaps JPEG and TGA-files. The format used for the TGA's are 16-bit uncompressed RGB. 

An entire .til file may be exported as a script file and a set of images. The images will be stored in a subdirectory with the same name as the script file (excluding the file-extension).

It is possible to import these scriptfiles, thereby generating a new .til-file. (note that exporting and subsequently importing the generated script, may result in a slightly different .til file. This is in part due to the color-conversion taking place and in part due to shadow- and/or transparent-color being the same as the color of pixels that are not transparent or shadow in the original .til file).

Finally it is possible to append to a tile-file either a complete .til-file or from a script. Due to the nature of the tile-file it might be advisable to use script-import for appending one tile-file to another, as the append option does NOT check for duplicate resouce names.

Formats:
  The TileID consists of three numbers:
    1 ID (Refferenced in TileRules)
    2 TileSet (Index refferenced in tiles.txt)
    3 Cutout value (sum of the borders that are black)

  The BorderID consists of two values
    1 TileSet Index of the Tile that's on the inside
    2 TileSet Index of the Tile that's on the outside

  Se "Script File Format.txt" for more details.
  
Known bugs:
  As far as I kow there are only two bugs:
  - when you save an image using the System color as background color the
    color used is black.
  - For some display cards zoom 2-4 times will blur the image. This is most 
    likely a Windows bug. (Other programs does the same)



History:
V.1.1.0.30
- Fixed cut-out-border issue, for script import, where borders were not cut 
  out of the tile.
- Updated Script file format (current version is now 1.1)
    VariationRules can now be in human readable format.
    (se "Script file format.txt" for details)

V.1.1.0.29
- Fixed cut-out-border issue, where borders would appear on all four sides,
  if one border was needed.
- Fixed minor typo (hint text)

V.1.1.0.28
- Options page windows size bug fixed.
- The colors used when importing tga-files can now be saved to the
  ini-file, and default colors can be set on the Options meue.
- Helpfile has been updated.

V.1.1.0.27 Date 18-10-2003
- LastBlock renamed to VariationRule, as I, with a lot of help from Mc, 
  finally figured out what it was.
- Changed the TextEdit format of the Variation Rule property page.
- Added Graphical display for the Variation Rule.
- Updated the Help-file to reflect our new understanding of the 
  Variation Rule.

V.1.0.0.26 Date 03-10-2003
- Added automatic cutout of borders for tiles.
- Added register .til-file with TileEdit.
- Added a scrollable list of the apropriate resource to the 
  Add/Edit Dialog.
- Added Reset .ini-file. (and optimized the .ini-file usage).
- ZoomFactor is now saved to the ini-file.
- Background and Shadow colors are now saved to the ini-file.
- Fixed a few bugs on the options page.
- Fixed import of Tiles in InGame-Color-Mode, so the colors displayd 
  are now correct.
- Fixed a size bug for the Add/Edit and Options Dialogs, I saved and
  loaded the sizes and not only the possitions to/from the ini-file.

V.1.0.0.25 Date 04-12-02
- Added jpeg as option for Save Image.
- Added image border size on the options page.
- Fixed not saving file if extention was not all lowercase.
- Fixed a menu-color bug, with custom windows menue colors.

V.1.0.0.24 Date 13-11-02
- Added append option so it is now possible to append a whole tile-file or a script.

V.1.0.0.23 Date 11-11-02
- Fixed disapearing cutout values

V.1.0.0.22 Date 02-05-02
- Final relese. (at least I hope so)
- Fixed dubble assignment to shortcut.
    Change color mode is now Ctrl + C

V.0.3.0.21 Date 13-02-02
- Full Help-file. (more or less)
- Added put last option on Add Resource screen.
- Added to high resource possition protection.
- Removing the Replace check-mark on the Eddit Resource screen now results
  in the eddited resource being added/inserted and not a blank resource.
- Fixed a bug from build 20 where the LastBlock edit field did not get
  displayed.
- All windows possitions and sizes are now saved to and restored from
  the .ini-file.
- The Close button in the import-log-window now closes the window.
- 'Tile Rule Number' now follows Tile if 'Show Tile Rule' is not checked.
- Fixed disapearing check-mark on tile-borders-properties page.
- Added a label to the River type drop-down-list.
- Fixed dubble assignment to shortcuts. Save Images is now
    Tile	Shift + Ctrl + E
    Borders	Shift + Ctrl + D
    River	Shift + Ctrl + V
    Improvement	Shift + Ctrl + P

V.0.3.0.20b Date 07-09-01
- Changed the Hex numbers displayed to the more logical HiLo in stead of LoHi
  (same for the script generator) and a few minor cosmetic changes.
- Borders can now be loaded in two ways: 
  1. all four from TGA
  2. one of the four from TGA, wich is then copied to the other three.

V.0.3.0.19b Date 05-09-01
- Fixed Resource Possition Numbers in Edit Screen
- Added New to the File menu, creates a new blank TileFile.
- Found and fixed a few new bugs introduced in build 18.
- Fixed a bug where adding TileBorders in InGame-mode would result in funny
  colors in saved files.
- Fixed a bug where swiching color mode after adding resources in InGame mode
  the colors of the new resources would be corupted.
- Added Edit/Add captions to Resource Property Edit Box.

V.0.3.0.18b Date 04-09-01
- Fixed disappearing Script-File-Directory.
- Changed default TileSet-save-name to gtset555.til/gtset565.til 
- added overwrite prompting (configurable).
- Log now shows Tile-Graphics-Filenames and not needed borders.
- Show hex now also affects Resource IDs.
- Fixed a bug where importing some TGA's might cause TileEdit to crash.
- Log shows number of resources read out of total.
- Added an Import Log window (Ctrl+W) with 'Stay On Top' capability.

V.0.3.0.17b Date 30-08-01
- Added two extra levels of Script Import Logging.
  - Extensive: Just a few extra things added, but will be saved even 
    at a crash.
  - Total: Everything is logged. One entry for each element success or failure.
  Using these two will result in a slower load, since each load operation is
  logged and saved to disk as it occurs.
- Fixed Import Script Open Dialog Initial dir. Now using 'Script file 
  Directory' as per Options page.

V.0.3.0.16b Date 28-08-01
- Fixed error where attempting to set 'Tile Image Directory' on Options 
  page resulted in setting 'Tile File Directory'
- The Load TGA on the Resource property page will now use Dirs as per
  Options page.
- Double clicking an edit field on the Options page now opens the Select
  Directory dialog.
  
V.0.3.0.15b Date 28-08-01
- Added Options page and .ini-file (only directories for now)
- TileEdit will now use the last directory used (default), or a directory
  specified on the options page, after restart.
- Fixed a missing SpinEdit box on the Tile-Properties page.
- Got started on the some help. (options page)

V.0.3.0.14b Date 27-08-01
- Speeded up Script Import.
- Fixed wrong dialog title, file type etc.
- Fixed a few places where loading invalid files would cause crashes. 
  (There might still be some)
- Added error messages for loading invalid images.
- Save Image now saves 3x3 view if selected.
- Added import-log-file.
- Added Import-Error-Message-Dialog.

V.0.3.0.13b Date 22-08-01
- Fixed Show Hex Numbers. Now the numbers shown are hexadecimal if this
  option is checked.
- Added Script Import.
- Added 'Image Directory' to Script

V.0.3.0.12b Date 21-08-01
- Added short-cuts to 3x3 and Single display.
- Resized window to fit on a 800x600 screen.
- Fixed a few interface bugs.
  - fixed error where switching from 3x3 to Single caused image to be stretched.
  - fixed a few typos.
  - Number of LastBlocks is now displayed correctly.
- Fixed two in-game colors bugs, 
  - fixed error when loading tiles 
  - fixed failure to update color mode for TileBorders

V.0.3.0.11b Date 20-08-01
- Changed name to TileEdit

V.0.2.0.10b Date 20-08-01 (not publicly released)
- Added Add, Delete, and Edit Last Block.
- Fixed a bug where Add River would not add the River, but some invalid element
  causing a crash when viewing the River.

V.0.2.0.9b Date 20-08-01
- Added Import Tiles graphics
- The load TGA-Preview background will now change to a color different from
  the transparent/background color.
- Fixed a few bugs. (seems there were some in there after all ;))

V.0.2.0.8b Date 17-08-01
- Added support for both in game- and standard 16 bit color mode.
- Save Tile File will now save two files: normal and in-game color coding.
- Added Display TileRules
- Now displays TileRules for tile being viewed.
- Added Add, Edit, and Delete for all Known element types, except Import of
  tile graphics. (Import can handle 16, 24, and 32 bit RGB .tga's) 
- Added Transparent and Shadow colors to Script.
- Added a 3x3 mode to the view. This will display up to 9 tiles based on the
  current tile rule. (And current tile)

V.0.2.0.7b Date 08-08-01
- Changed the Script generator:
  - The Tile-Rules layout is now more logical.
  - The River-orientation now has same format as for Tile-Rules

V.0.2.0.6b Date 08-08-01
- Added Save for ALL graphical elements, that is: Tiles, Rivers, Improvements,
  Borders, and Whatever Image is Displayed in the preview window.(.tga)
- Added support for varying size Tile Improvements. So now the whole road,
  railroad, or MagLev is displayed.
- The cut-out borders are now displayed. (So now it's all there)
- Added 'Export' which will generate a script file (.src) and save all graphical
  elements to separate images, in a directory with the same name as the .src
  file.
- Added 'Save Tile File' which will save as a .til file (not much use for that
  until I get the import stuff added though, but one of them had to come first).

V.0.2.0.5b Date 03-08-01
- Totally redesigned the interface.
- TileView now correctly displays all Tile Improvements 
  (except one, that's to large, this will be fixed in the next version)
- Shadows are now displayed correctly.
- Added a Shadow-color menu.
- Zoom now goes to 8 plan for a Zoom Menu up to 16.
- Added About-Box.

V.0.1.0.4b Date 25-07-01
- The overlapping portions of all tiles are now drawn correctly.
- Recognizes and displays rivers
- Added zoom.
- Added Shortcuts to most Menus.
- Added save TileImage (Only as BMP for now - the easiest)

V.0.1.0.3b Date 24-07-01
- TileView now recognizes the overlapping portions of most tiles.
  Some tiles are not displayed properly: some portions missing and
  some overwriting itself.
- Added image background color menu.
- Open File now displays only .til files by default (can display all files)

V.0.1.0.2b Date 14-07-01
- Minor bug-fix: There was a error where a 24 had become a 23.

Things in progress(Wish list):

- better support for 3x3
